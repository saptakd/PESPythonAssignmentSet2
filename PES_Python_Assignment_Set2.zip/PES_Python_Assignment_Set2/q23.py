#Math – math.pi application
'''23.Find the area of Circle given that radius of a circle.
( Use pi value from Math module)'''
import math
rad=int(input("Enter value of radius"))
area=math.pi*rad*rad
print "The area of circle is",area,"sqmeters"
